import React, { useEffect, useRef, useState } from "react";
import { FaTimes } from "react-icons/fa";
import CodeMirror from "@uiw/react-codemirror";
import { getCodeById, updateCodeFile } from "../api/codeApi";
import { runJsPreview, runHtmlPreview } from "../api/previewApi";

const SelfCodingEditorPanel = ({
  tabs,
  setTabs,
  activeTab,
  currentFolderId,
  setActiveTab,
  selectedFilename,
  setSelectedFilename,
  selectedFileContent,
  setSelectedFileContent,
  templateId,
  templateDescriptions,
  getLanguageExtension,
  setUnsaved,
  unsaved,
  languageId,
  setLanguageId,
  setPreviewSrcDoc,
  setPreviewTabs,
  setActivePreviewTab,
}) => {
  const editorRef = useRef(null);
  const [originalContent, setOriginalContent] = useState("");
  const extension = selectedFilename?.split(".").pop();

  const handleSave = async () => {
    if (!activeTab) return;
    const codeId = parseInt(activeTab.replace("code-", ""));
    try {
      await updateCodeFile(codeId, { content: selectedFileContent, language_id: languageId });
      setOriginalContent(selectedFileContent);
      setUnsaved(false);
    } catch (err) {
      console.error("파일 저장 실패", err);
      alert("저장 실패");
    }
  };

  const handleRunJs = async () => {
    try {
      const result = await runJsPreview(selectedFileContent);
      console.log("🔥 runJs 결과:", result);
  
      const escapedCode = selectedFileContent.replace(/<\/script>/g, "<\\/script>");
  
      const jsOutput = `
        <html>
          <body style="font-family:monospace; padding:20px;">
            <pre id="output"></pre>
            <script>
              (function() {
                const log = console.log;
                const output = document.getElementById("output");
                console.log = function(...args) {
                  args.forEach(arg => {
                    output.innerText += arg + "\\n";
                  });
                  log.apply(console, args);
                };
                try {
                  ${escapedCode}
                } catch (e) {
                  output.innerText += "🚨 오류: " + e.message;
                }
              })();
            </script>
          </body>
        </html>
      `;
  
      setPreviewSrcDoc(jsOutput);
      setPreviewTabs((prev) => {
        if (!prev.includes(selectedFilename)) return [...prev, selectedFilename];
        return prev;
      });
      setActivePreviewTab(selectedFilename);
    } catch (err) {
      console.error("JS 실행 실패", err);
      alert("실행 중 오류가 발생했습니다.");
    }
  };
  
  const handleRunHtml = async () => {
    try {
      const codeId = parseInt(activeTab?.replace("code-", ""));
      if (!codeId) throw new Error("올바른 코드 ID가 아닙니다.");
  
      const result = await runHtmlPreview(codeId); // 🔄 이제 codeId만 넘긴다
  
      setPreviewSrcDoc(result.srcdoc);
      setPreviewTabs((prev) => {
        if (!prev.includes(result.html_filename)) return [...prev, result.html_filename];
        return prev;
      });
      setActivePreviewTab(result.html_filename);
    } catch (err) {
      console.error("HTML 실행 실패 Error:", err.message);
      alert("HTML 실행 중 오류: " + err.message);
    }
  };

  useEffect(() => {
    const fetchContent = async () => {
      if (!activeTab) return;
      try {
        const id = parseInt(activeTab.replace("code-", ""));
        const code = await getCodeById(id);
        setSelectedFilename(code.title);
        setSelectedFileContent(code.content);
        setOriginalContent(code.content);
        setLanguageId(code.language_id);
        setUnsaved(false);
      } catch (err) {
        console.error("파일 내용 불러오기 실패", err);
        setSelectedFileContent("// 파일 불러오기 실패");
      }
    };
    fetchContent();
  }, [activeTab]);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "s") {
        e.preventDefault();
        handleSave();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [selectedFileContent]);

  const renderActionButton = () => {
    if (unsaved || extension === "css") {
      return (
        <button
          className="text-[12px] text-blue-600 hover:text-blue-800 px-2 py-0.5 border border-blue-300 rounded"
          onClick={handleSave}
        >
          💾 저장
        </button>
      );
    }
  
    if (selectedFilename.endsWith(".js")) {
      return (
        <button
          className="text-[12px] text-green-600 hover:text-green-800 px-2 py-0.5 border border-green-300 rounded"
          onClick={handleRunJs}
        >
          ▶ JS 실행
        </button>
      );
    }
  
    if (selectedFilename.endsWith(".html")) {
      return (
        <button
          className="text-[12px] text-purple-600 hover:text-purple-800 px-2 py-0.5 border border-purple-300 rounded"
          onClick={() => handleRunHtml(currentFolderId)}  // ⚠️ 여기에 폴더 ID 필요
        >
          🌐 HTML 실행
        </button>
      );
    }
  
    return null;
  };

  return (
    <div className="flex flex-col w-full h-full bg-white border-r border-gray-200">
      <div className="flex items-center overflow-x-auto bg-[#f3f3f3] border-b border-gray-300 px-2 py-1">
        {tabs.map((tab) => {
          const fileName = tab.split("/").pop();
          const emoji = templateDescriptions[templateId]?.emoji || "📄";
          const isActive = tab === activeTab;
          const isUnsaved = isActive && unsaved;
          return (
            <div
              key={tab}
              className={`flex items-center px-3 py-1 mr-1 rounded-t-md text-sm font-medium border cursor-pointer ${
                isActive
                  ? "bg-white text-black border-t border-l border-r border-gray-300"
                  : "bg-[#e0e0e0] text-gray-600 hover:bg-[#d5d5d5] border border-transparent"
              }`}
              onClick={() => setActiveTab(tab)}
            >
              <span className="mr-2">{emoji}</span>
              <span>{selectedFilename}{isUnsaved && " ●"}</span>
              <FaTimes
                className="ml-2 text-xs hover:text-red-500"
                onClick={(e) => {
                  e.stopPropagation();
                  setTabs((prev) => prev.filter((t) => t !== tab));
                  if (activeTab === tab) {
                    const nextTab = tabs.find((t) => t !== tab);
                    setActiveTab(nextTab || "");
                    setSelectedFilename(nextTab || "");
                    setSelectedFileContent("");
                  }
                }}
              />
            </div>
          );
        })}
      </div>
      <div className="flex justify-between items-center px-4 py-1 text-xs text-gray-500 border-b border-gray-200 bg-white font-mono">
        <div>{selectedFilename || "파일을 선택하세요"}</div>
        {renderActionButton()}
      </div>
      <div className="flex-1 p-4 overflow-auto">
        <CodeMirror
          ref={editorRef}
          value={selectedFileContent}
          height="100%"
          theme="light"
          extensions={[getLanguageExtension(selectedFilename)]}
          onChange={(value) => {
            setSelectedFileContent(value);
            setUnsaved(value !== originalContent);
          }}
          basicSetup={{ lineNumbers: true }}
          style={{
            fontFamily:
              "'Fira Code', 'JetBrains Mono', Menlo, Monaco, Consolas, 'Courier New', monospace",
            fontSize: "14px",
            lineHeight: "1.5",
          }}
        />
      </div>
    </div>
  );
};

export default SelfCodingEditorPanel;
